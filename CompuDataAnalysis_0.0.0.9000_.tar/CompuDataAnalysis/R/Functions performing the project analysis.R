#' Load a CSV file based on a filename pattern
#'
#' This function searches for a CSV file whose name matches a given pattern
#' within the current directory and its subdirectories. If one or more files
#' match, the first one found is read into R using `fread` from the **data.table** package.
#'
#' @param file_name_pattern A character string specifying the filename pattern
#' to search for (regular expressions are supported).
#'
#' @return A data.table containing the contents of the first CSV file that matches
#' the specified pattern.
#'
#' @details
#' The function is useful when working with files located in nested folders
#' or when filenames include variable parts (e.g., timestamps). It automatically
#' searches recursively and loads the first matching file.
#'
#' @examples
#' # Load a file named 'bulk_counts_long.csv' (or similar)
#' bc <- load_csv("bulk_counts_long\\.csv")
#'
#' @seealso [data.table::fread()], [list.files()]
#'
#' @export

# Function to load a CSV file based on its name
load_csv <- function(file_name_pattern) {

  # Search for the file in the current directory and subfolders
  files <- list.files(path = ".", pattern = file_name_pattern, recursive = TRUE, full.names = TRUE)

  # Check if at least one file was found
  if(length(files) == 0) {
    stop(paste0("File matching '", file_name_pattern, "' not found!"))
  }

  # Read the first file found
  dt <- fread(files[1])

  return(dt)
}



######################################################################################################################################################################################

#' Summarize bulk RNA-seq count data by gene and condition
#'
#' This function merges bulk RNA-seq count data (`bc`) with sample metadata (`meta`),
#' filters the data by a specified experimental condition and gene name pattern,
#' and computes the mean expression count per gene within that condition.
#' The result is a summarized table showing average gene expression for
#' the selected condition only.
#'
#' @param bc A data.frame or tibble containing bulk count data, with at least
#'   the columns \code{sample_id}, \code{gene}, and \code{count}.
#' @param meta A data.frame or tibble containing sample metadata, with at least
#'   the columns \code{sample_id} and \code{condition}.
#' @param condition_filter A character string specifying which experimental
#'   condition to include in the summary (e.g., \code{"treated"} or \code{"control"}).
#' @param gene_pattern A regular expression used to select genes by name
#'   (e.g., \code{"^GENE_00"} to match genes starting with \code{GENE_00}).
#'
#' @return A tibble with the following columns:
#' \itemize{
#'   \item \code{gene} – gene identifier
#'   \item \code{condition} – the selected condition
#'   \item \code{mean_per_condition} – mean expression count for that gene
#'     under the specified condition
#' }
#'
#' @details
#' Steps performed by the function:
#' \enumerate{
#'   \item Merge bulk count data and metadata using \code{sample_id}.
#'   \item Filter rows to include only the specified condition and genes that
#'         match the given regular expression pattern.
#'   \item Compute the mean count per gene within that condition using \code{dplyr::summarise()}.
#'   \item Arrange the resulting summary table in descending order of mean expression.
#' }
#'
#' This version of the function uses the \pkg{dplyr} grammar, which makes the
#' operations highly readable but internally handles grouped data differently
#' from \pkg{data.table}.
#'
#' @examples
#' # Example usage:
#' # Summarize expression for genes starting with "GENE_00" in the "treated" condition
#' res <- summarize_bulk_counts(
#'   bc = bc,
#'   meta = meta,
#'   condition_filter = "treated",
#'   gene_pattern = "^GENE_00"
#' )
#'
#' # Display the top genes
#' head(res, 5)
#'
#' @seealso [dplyr::summarise()], [dplyr::filter()], [dplyr::arrange()]
#'
#' @export
summarize_bulk_counts <- function(bc, meta, condition_filter, gene_pattern) {
  # 1. Merge count data with metadata
  bc_meta <- merge(bc, meta, by = "sample_id")

  # 2. Filter rows: keep only the selected condition and genes
  filtered <- bc_meta %>%
    filter(
      condition == condition_filter,
      grepl(gene_pattern, gene)
    )

  # 3. Summarize: mean count per gene within that condition
  summarized <- filtered %>%
    group_by(gene, condition) %>%
    summarise(mean_per_condition = mean(count, na.rm = TRUE)) %>%
    arrange(desc(mean_per_condition))

  # 4. Return the summarized table
  return(summarized)
}



#######################################################################################################################################################################################' Add log2-transformed counts and high-expression flag
#'
#' This function takes a data.table of gene expression counts and adds two new columns:
#' a log2-transformed count (\code{log2_count}) and a logical flag (\code{high}) indicating
#' whether each count is above the gene-specific median.
#'
#' @param bc_dt A data.table containing at least the columns \code{gene}, \code{sample_id},
#' and \code{count}. If the input is not a data.table, it will be converted automatically.
#'
#' @return A data.table identical to the input but with two additional columns:
#' \itemize{
#'   \item \code{log2_count} – the log2-transformed count (\code{log2(count + 1)})
#'   \item \code{high} – a logical flag indicating whether the count is higher than
#'         the median count for that gene across all samples
#' }
#'
#' @details
#' The function first ensures that the input is a data.table, then calculates the
#' log2-transformed counts without duplicating the full dataset in memory. The initial
#' high flag (count > 100) is replaced by a gene-wise threshold based on the median count.
#'
#' @examples
#' # Example usage once loaded data(bc):
#' bc <- add_log_and_high_flag(bc)
#' head(bc)
#'
#' @seealso [data.table::as.data.table()], [base::log2()], [stats::median()]
#'
#' @import data.table
#'
#' @export
add_log_and_high_flag <- function(bc_dt) {

  # Check that input is a data.table
  if(!is.data.table(bc_dt)) bc_dt <- as.data.table(bc_dt)

  # Add log2(count) WITHOUT copying the entire table
  bc_dt[, log2_count := log2(count + 1)]

  # Initial high flag (count > 100)
  bc_dt[, high := count > 100]

  # Overwrite high flag using a gene-wise threshold (median per gene)
  bc_dt[, high := count > median(count), by = gene]

  return(bc_dt)
}
#######################################################################################################################################################################################' Analyze join performance and indexing in data.table
#'
#' This function demonstrates how to perform joins and use indexing with
#' the **data.table** package in R. It joins bulk count data with metadata,
#' applies a secondary index, and benchmarks query performance before and after
#' indexing to show the performance impact.
#'
#' @param bc A data.table containing bulk count data with at least the columns
#' \code{sample_id}, \code{gene}, and \code{count}.
#' @param meta A data.table containing sample metadata with at least the column
#' \code{sample_id}, which is used as the join key.
#'
#' @return A list with three elements:
#' \itemize{
#'   \item \code{joined} – a data.table resulting from joining \code{bc} with \code{meta}
#'   \item \code{benchmark} – the raw output from \code{microbenchmark()} comparing
#'         query times with and without indexing
#'   \item \code{summary} – a summarized data.table showing mean, median, min, and max
#'         benchmark times (in milliseconds)
#' }
#'
#' @details
#' The function performs several operations:
#' \enumerate{
#'   \item Validates that both inputs are data.tables.
#'   \item Sets a primary key on the metadata table for efficient joins.
#'   \item Joins the metadata and count data on \code{sample_id}.
#'   \item Adds a secondary index on \code{(gene, sample_id)} in the count table.
#'   \item Benchmarks a subset query before and after indexing using \code{microbenchmark()}.
#'   \item Generates a summary table of benchmark results with rounded values.
#' }
#'
#' The goal is to illustrate how indexing can significantly improve
#' query speed in large datasets handled by data.table.
#'
#' @examples
#' # Example usage:
#' bc   <- load_csv("bulk_counts_long\\.csv")
#' meta <- load_csv("sample_metadata\\.csv")
#'
#' result <- analyze_join_index(bc, meta)
#'
#' # View results
#' head(result$joined)
#' result$summary
#'
#' @seealso [data.table::setkey()], [microbenchmark::microbenchmark()], [data.table::merge()]
#'
#' @export
analyze_join_index <- function(bc, meta) {
  # 1. Validity checks
  if (!is.data.table(bc))  stop("'bc' must be a data.table.")
  if (!is.data.table(meta)) stop("'meta' must be a data.table.")

  # 2. Set primary key on metadata
  setkey(meta, sample_id)

  # 3. Perform an equi-join on sample_id
  bc_joined <- meta[bc, on = "sample_id"]
  cat("\n### First 5 rows after join:\n")
  print(head(bc_joined, 5))

  # 4. Add secondary index on (gene, sample_id)
  setkey(bc, gene, sample_id)

  # 5. Benchmark: query before and after indexing
  bc_noindex <- copy(bc)
  setkey(bc_noindex, NULL)

  query_subset <- function(dt) {
    dt[gene == "GENE_001" & sample_id == "S1"]
  }

  bm <- microbenchmark(
    without_index = query_subset(bc_noindex),
    with_index    = query_subset(bc),
    times = 20
  )

  cat("\n### Benchmark subset query before/after secondary index:\n")
  print(bm)

  # 6. Summary table using only data.table syntax
  bm_dt <- as.data.table(summary(bm))
  bm_dt[, `:=`(
    mean   = round(mean, 4),
    median = round(median, 4),
    min    = round(min, 4),
    max    = round(max, 4)
  )]
  summary_table <- bm_dt[, .(expr, mean, median, min, max)]

  cat("\n### Summary table (ms):\n")
  print(summary_table)

  # 7. Output
  return(list(joined = bc_joined, benchmark = bm, summary = summary_table))
}

#######################################################################################################################################################################################' Analyze bulk count data using data frames
#'
#' This function performs exploratory analysis on bulk RNA count data stored in
#' standard R data frames or tibbles. It joins count data with sample metadata,
#' computes total counts per patient, and identifies the top 10 genes with the
#' highest average expression within each experimental condition.
#'
#' @param bc_df A data frame or tibble containing bulk count data with at least
#' the columns \code{sample_id}, \code{gene}, and \code{count}.
#' @param meta_df A data frame or tibble containing sample metadata with at least
#' the column \code{sample_id}, which will be used to join with the count data.
#'
#' @return A list with two elements:
#' \itemize{
#'   \item \code{patient_totals} – a data frame showing total counts per patient.
#'   \item \code{top_genes} – a data frame showing the top 10 genes by average
#'         count for each condition.
#' }
#'
#' @details
#' The function performs the following operations:
#' \enumerate{
#'   \item Joins the bulk count data with sample metadata by \code{sample_id}.
#'   \item Calculates the total count per patient to summarize overall expression levels.
#'   \item Computes the average count for each gene within each condition.
#'   \item Selects the top 10 genes with the highest average counts per condition.
#'   \item Returns both summary tables in a list for downstream analysis.
#' }
#'
#' @examples
#' # Example usage once loaded the data (bc,meta):
#'
#' results <- analyze_bulk_counts_df(bc, meta)
#'
#' # Inspect results
#' head(results$patient_totals)
#' head(results$top_genes)
#'
#' @seealso [dplyr::left_join()], [dplyr::group_by()], [dplyr::summarise()], [dplyr::arrange()]
#'
#' @export

analyze_bulk_counts_df <- function(bc_df, meta_df) {
  # 1. Join counts with metadata
  bc_meta_df <- bc_df %>%
    left_join(meta_df, by = "sample_id")

  # 2. Calculate total counts per patient
  patient_totals_df <- bc_meta_df %>%
    group_by(patient_id) %>%
    summarise(total_count = sum(count), .groups = "drop")

  cat("\n### Per-patient total counts (data.frame):\n")
  print(head(patient_totals_df, 5))

  # 3. Calculate top 10 genes by average count within each condition
  top_genes_df <- bc_meta_df %>%
    group_by(condition, gene) %>%
    summarise(avg_count = mean(count), .groups = "drop") %>%
    arrange(condition, desc(avg_count)) %>%
    group_by(condition) %>%
    slice_head(n = 10)

  cat("\n### Top 10 genes by average count per condition (data.frame):\n")
  print(top_genes_df)

  # 4. Return both results in a list
  return(list(
    patient_totals = patient_totals_df,
    top_genes = top_genes_df
  ))
}


######################################################################################################################################################################################
#' Classify abnormal laboratory results based on reference ranges
#'
#' This function compares laboratory measurements against reference ranges to
#' classify each result as either normal or out of range. It supports optional
#' metadata such as patient sex to enable sex-specific reference intervals.
#'
#' @param labs_dt A \code{data.table} containing laboratory results with at least
#' the columns \code{patient_id}, \code{lab}, and \code{value}.
#' @param refs_dt A \code{data.table} containing reference ranges with at least
#' the columns \code{lab}, \code{lower}, and \code{upper}. Optionally, it may include
#' \code{sex} to define sex-specific ranges.
#' @param meta_dt (optional) A \code{data.table} or data frame containing metadata
#' about patients, such as \code{patient_id} and \code{sex}. If provided, it will
#' be joined to \code{labs_dt} to allow sex-specific classification.
#'
#' @return A list with three elements:
#' \itemize{
#'   \item \code{labeled} – a data.table containing the original lab data with an added
#'         \code{status} column indicating whether each result is \code{"normal"}
#'         or \code{"out_of_range"}.
#'   \item \code{by_patient} – a summary table showing the total number of results,
#'         number of abnormal results, and abnormal rate per patient.
#'   \item \code{by_lab} – a summary table showing the total number of results,
#'         number of abnormal results, and abnormal rate per laboratory test.
#' }
#'
#' @details
#' The function performs the following steps:
#' \enumerate{
#'   \item Validates input types and converts metadata to a data.table if needed.
#'   \item Joins metadata with laboratory data when available.
#'   \item Sets keys on the reference table to allow efficient joins.
#'   \item Performs a non-equi join to classify values as \code{"normal"}
#'         if they fall within the reference range.
#'   \item Labels all remaining values as \code{"out_of_range"}.
#'   \item Calculates abnormal result rates by patient and by lab.
#' }
#'
#' @examples
#' # Example usage once data loaded (labs_dt, refs_dt ):
#'
#' results <- classify_abnormal_labs(labs_dt, refs_dt)
#'
#' # View results
#' head(results$labeled)
#' results$by_patient
#' results$by_lab
#'
#' @seealso [data.table::foverlaps()], [data.table::setkey()], [data.table::merge()]
#'
#' @export
classify_abnormal_labs <- function(labs_dt, refs_dt, meta_dt = NULL) {
  # Check input types
  stopifnot(is.data.table(labs_dt), is.data.table(refs_dt))
  if (!is.null(meta_dt) && !is.data.table(meta_dt)) {
    meta_dt <- as.data.table(meta_dt)
  }

  # If available, add metadata information (e.g., sex)
  if (!is.null(meta_dt) && "sex" %in% names(meta_dt)) {
    labs_dt <- meta_dt[labs_dt, on = "patient_id"]
  }

  # Set key on reference table
  if ("sex" %in% names(refs_dt) && "sex" %in% names(labs_dt)) {
    setkey(refs_dt, lab, sex)
  } else {
    setkey(refs_dt, lab)
  }

  # Non-equi join with reference intervals
  labeled_dt <- refs_dt[labs_dt, on = .(lab), allow.cartesian = TRUE][
    value >= lower & value <= upper, status := "normal"
  ]

  # Label remaining rows as out_of_range
  labeled_dt[is.na(status), status := "out_of_range"]

  # Calculate abnormal rates per patient
  abnormal_patient <- labeled_dt[, .(
    n_total = .N,
    n_abnormal = sum(status == "out_of_range"),
    rate_abnormal = mean(status == "out_of_range")
  ), by = patient_id]

  # Calculate abnormal rates per lab
  abnormal_lab <- labeled_dt[, .(
    n_total = .N,
    n_abnormal = sum(status == "out_of_range"),
    rate_abnormal = mean(status == "out_of_range")
  ), by = lab]

  # Return all results
  return(list(
    labeled = labeled_dt,
    by_patient = abnormal_patient,
    by_lab = abnormal_lab
  ))
}

######################################################################################################################################################################################
#' Match CRP laboratory values with vital signs and compute correlations
#'
#' This function matches CRP laboratory measurements with vital sign records
#' (e.g., heart rate and systolic blood pressure) based on the closest timestamps
#' within each patient. It then computes correlations between CRP values and
#' selected vital signs for each patient.
#'
#' @param labs_dt A \code{data.table} containing laboratory data with at least
#' the columns \code{patient_id}, \code{time_iso}, \code{lab}, and \code{value}.
#' @param vitals_dt A \code{data.table} containing vital sign measurements with
#' at least the columns \code{patient_id}, \code{time_iso}, \code{vital}, and \code{value}.
#'
#' @return A list with two elements:
#' \itemize{
#'   \item \code{merged} – a data.table where each CRP measurement is matched
#'         to the nearest vital sign observation within the same patient.
#'   \item \code{correlations} – a data.table showing per-patient correlation
#'         coefficients between CRP values and vital signs (currently heart rate and systolic blood pressure).
#' }
#'
#' @details
#' The function performs the following steps:
#' \enumerate{
#'   \item Converts timestamp columns to POSIXct format for accurate time matching.
#'   \item Reshapes vital sign data from long to wide format.
#'   \item Filters CRP measurements from the lab dataset and renames relevant columns.
#'   \item Sets keys on both datasets by \code{patient_id} and timestamp.
#'   \item Performs a rolling join to find the nearest vital sign record to each CRP measurement.
#'   \item Computes correlations between CRP values and vital signs (HR and SBP) for each patient.
#' }
#'
#' @examples
#' # Example usage once data are loaded (labs_dt,vitals_dt):
#'
#' results <- match_labs_vitals(labs_dt, vitals_dt)
#' head(results$merged)
#' head(results$correlations)
#'
#' @seealso [data.table::dcast()], [data.table::setkey()], [data.table::merge()], [data.table::foverlaps()]
#'
#' @export
match_labs_vitals <- function(labs_dt, vitals_dt) {
  library(data.table)

  # ---- CONVERT TIME COLUMNS ----
  labs_dt[,   time_iso := as.POSIXct(time_iso)]
  vitals_dt[, time_iso := as.POSIXct(time_iso)]

  # ---- PIVOT VITALS TO WIDE FORMAT ----
  vitals_wide <- dcast(vitals_dt, patient_id + time_iso ~ vital, value.var = "value")

  # ---- FILTER AND RENAME CRP LABS ----
  crp_labs <- labs_dt[lab == "CRP"]
  setnames(crp_labs, "time_iso", "lab_time")
  setnames(crp_labs, "value",    "lab_value")

  # ---- SET KEYS ----
  setkey(vitals_wide, patient_id, time_iso)
  setkey(crp_labs,    patient_id, lab_time)

  # ---- PERFORM ROLLING JOIN (NEAREST MATCH) ----
  merged_dt <- vitals_wide[crp_labs, on = .(patient_id, time_iso = lab_time), roll = "nearest"]

  # ---- CALCULATE CORRELATIONS ----
  correlation_dt <- merged_dt[, .(
    cor_HR  = cor(lab_value, HR , use = "complete.obs"),
    cor_SBP = cor(lab_value, SBP, use = "complete.obs")
  ), by = patient_id]

  # ---- OUTPUT RESULTS ----
  print(head(merged_dt, 5))
  print(head(correlation_dt, 5))

  # Return both tables as a list
  return(list(merged = merged_dt, correlations = correlation_dt))
}

######################################################################################################################################################################################

#' Get Top Genomic Peaks Within a Specific Interval
#'
#' This function filters a genomic peaks dataset (`data.table`) by chromosome and genomic coordinates,
#' then ranks the peaks by their score in descending order and selects the top N peaks.
#' It is useful for extracting the most significant genomic regions (e.g., ChIP-seq or ATAC-seq peaks)
#' within a specific genomic window.
#'
#' @param dt A `data.table` containing genomic peak data with at least the columns:
#'   \describe{
#'     \item{chr}{Chromosome name (character)}
#'     \item{start}{Genomic start position (numeric)}
#'     \item{score}{Peak score or intensity (numeric)}
#'   }
#' @param chromosome A character string specifying the chromosome to filter (e.g., `"chr2"`).
#' @param start_min Numeric value indicating the minimum start coordinate for filtering.
#' @param start_max Numeric value indicating the maximum start coordinate for filtering.
#' @param top_n Integer specifying how many top peaks to return (default is `50`).
#'
#' @return A `data.table` containing the top N peaks within the specified chromosome and coordinate range,
#' ordered by decreasing score.
#'
#' @examples
#' \dontrun{
#' top50_dt <- get_top_peaks(peaks_dt, "chr2", 2e6, 4e6, 50)
#' }
#'
#' @export
get_top_peaks <- function(dt, chromosome, start_min, start_max, top_n = 50) {
  # Filter by chromosome and genomic interval
  sub_dt <- dt[chr == chromosome & start >= start_min & start <= start_max]

  # Sort by score in descending order
  setorder(sub_dt, -score)

  # Select the top N peaks
  top_dt <- head(sub_dt, top_n)

  # Display the first 5 results
  cat("\n--- data.table: first 5 results ---\n")
  print(head(top_dt, 5))

  return(top_dt)
}
######################################################################################################################################################################################

#' Identify Upregulated Genes Between Treated and Control Conditions
#'
#' This function compares mean gene expression levels between treated and control conditions
#' and selects genes where the mean count in the treated group is at least twice that of the control group.
#'
#' @param cnt_dt A `data.table` containing gene count data with columns: `gene`, `sample_id`, and `count`.
#' @param meta_dt A `data.table` containing metadata with columns: `sample_id` and `condition`.
#'
#' @return A `data.table` containing genes that satisfy the condition `treated >= 2 * control`,
#' including the mean expression values for each condition.
#'
#' @details
#' The function performs the following steps:
#' \enumerate{
#'   \item Merges count data with condition metadata.
#'   \item Summarizes counts per gene and condition, computing mean, median, and quartiles.
#'   \item Transforms the summary into a wide format (genes as rows, conditions as columns).
#'   \item Filters genes whose mean expression in the treated group is at least twice that of the control group.
#' }
#'
#' @examples
#' \dontrun{
#' result <- get_upregulated_genes(cnt, meta)
#' head(result)
#' }
#'
#' @export
# Function to select genes where treated >= 2 * control
get_upregulated_genes <- function(cnt_dt, meta_dt) {
  # Merge count data with condition information
  dt <- merge(cnt_dt, meta_dt[, .(sample_id, condition)], by = "sample_id")

  # Summarize by gene and condition
  summ_dt <- dt[, .(
    mean   = mean(count, na.rm = TRUE),
    median = median(count, na.rm = TRUE),
    Q1     = quantile(count, 0.25, na.rm = TRUE),
    Q3     = quantile(count, 0.75, na.rm = TRUE)
  ), by = .(gene, condition)]

  # Convert to wide format (gene x condition)
  wide_dt <- dcast(summ_dt, gene ~ condition, value.var = "mean")

  # Select genes where treated >= 2 * control
  res_dt <- wide_dt[treated >= 2 * control]

  # Print first 5 results
  cat("\n=== First 5 genes satisfying treated >= 2*control ===\n")
  print(head(res_dt, 5))

  return(res_dt)
}

######################################################################################################################################################################################

#' Transform Wide Peak Data to Long Format and Compute Gene x Condition Statistics
#'
#' This function converts a wide-format peak or count table into long format,
#' merges it with sample metadata, computes total counts per sample, and calculates
#' summary statistics (mean, median, first and third quartiles) for each gene
#' within each experimental condition.
#'
#' @param peaks_wide A \code{data.table} in wide format with genes as rows and
#'   sample IDs as columns. Each cell contains the count or peak value.
#' @param meta_dt A \code{data.table} containing metadata for each sample, including
#'   at least the columns \code{sample_id} and \code{condition}. Additional columns
#'   (e.g., \code{batch}, \code{patient_id}, \code{timepoint}) will also be merged.
#'
#' @return A list with two elements:
#' \itemize{
#'   \item \code{long} – a long-format \code{data.table} where each row corresponds
#'         to a gene measurement for a sample, including metadata and total counts per sample.
#'   \item \code{gene_condition} – a \code{data.table} summarizing each gene by
#'         condition, including \code{mean_count}, \code{median_count}, first quartile (\code{Q1}),
#'         and third quartile (\code{Q3}) values.
#' }
#'
#' @details
#' The function performs the following steps:
#' \enumerate{
#'   \item Melts the wide-format table to long format.
#'   \item Ensures sample IDs are of type character in both datasets.
#'   \item Computes total counts per sample.
#'   \item Merges the long data with metadata.
#'   \item Calculates summary statistics for each gene in each condition.
#' }
#'
#' @examples
#' \dontrun{
#' result <- process_peaks(peaks_wide, meta)
#' head(result$long)
#' head(result$gene_condition)
#' }
#'
#' @export
# Function to transform wide -> long format and compute statistics per gene x condition
process_peaks <- function(peaks_wide, meta_dt) {
  # Melt from wide to long format
  long_dt <- melt(
    peaks_wide,
    id.vars = "gene",
    variable.name = "sample_id",
    value.name = "count",
    variable.factor = FALSE
  )

  # Ensure sample_id is of type character
  long_dt[, sample_id := as.character(sample_id)]
  meta_dt[, sample_id := as.character(sample_id)]

  # Compute total counts per sample
  long_dt[, sample_total := sum(count, na.rm = TRUE), by = sample_id]

  # Merge metadata (adds condition, batch, etc.)
  long_dt <- meta_dt[long_dt, on = "sample_id"]

  # Compute statistics per gene x condition
  gene_cond <- long_dt[, .(
    mean_count   = mean(count, na.rm = TRUE),
    median_count = median(count, na.rm = TRUE),
    Q1           = quantile(count, 0.25, na.rm = TRUE),
    Q3           = quantile(count, 0.75, na.rm = TRUE)
  ), by = .(gene, condition)]

  # Print previews
  cat("\n[data.table] First 6 rows of long format:\n")
  print(head(long_dt, 6))

  cat("\n[data.table] First 6 rows of gene x condition mean counts:\n")
  print(head(gene_cond, 6))

  # Return list with intermediate and final results
  invisible(list(
    long = long_dt,
    gene_condition = gene_cond
  ))
}

######################################################################################################################################################################################

#' Compute Overlap Between Genomic Peaks and Genes
#'
#' This function calculates the base pair overlap between genomic peaks and gene coordinates,
#' summarizes the total overlap per gene, and returns the top N genes with the largest overlap.
#'
#' @param peaks_dt A \code{data.table} containing peak data with columns:
#'   \code{chr}, \code{start}, and \code{end}.
#' @param genes_dt A \code{data.table} containing gene coordinates with columns:
#'   \code{chr}, \code{gene}, \code{start}, and \code{end}.
#' @param top_n Integer specifying the number of top genes by total overlap to return (default 20).
#'
#' @return A list with three elements:
#' \itemize{
#'   \item \code{merged} – a \code{data.table} of all peak-gene pairs with overlapping intervals
#'         and the computed overlap in base pairs (\code{overlap_bp}).
#'   \item \code{gene_sum} – a \code{data.table} summarizing total overlap per gene (\code{total_overlap_bp}).
#'   \item \code{top_genes} – a \code{data.table} of the top N genes sorted by total overlap.
#' }
#'
#' @details
#' The function performs the following steps:
#' \enumerate{
#'   \item Converts start and end positions to numeric.
#'   \item Merges peaks and genes by chromosome, allowing all combinations.
#'   \item Filters only overlapping intervals.
#'   \item Computes the overlap in base pairs for each peak-gene pair.
#'   \item Aggregates total overlap per gene and selects the top N genes.
#' }
#'
#' @examples
#' \dontrun{
#' result <- compute_peak_gene_overlap(peaks_dt, genes_dt, top_n = 20)
#' head(result$top_genes)
#' }
#'
#' @export
# Function to calculate overlap between peaks and genes
compute_peak_gene_overlap <- function(peaks_dt, genes_dt, top_n = 20) {
  # Ensure start/end columns are numeric
  peaks_dt[, `:=`(start = as.numeric(start), end = as.numeric(end))]
  genes_dt[, `:=`(start = as.numeric(start), end = as.numeric(end))]

  # Merge by chromosome
  merged <- merge(peaks_dt, genes_dt, by = "chr", allow.cartesian = TRUE)

  # Keep only overlapping intervals
  merged <- merged[end.x >= start.y & start.x <= end.y]

  # Calculate overlap length in base pairs
  merged[, overlap_bp := pmin(end.x, end.y) - pmax(start.x, start.y)]

  # Sum total overlap per gene
  gene_sum <- merged[, .(total_overlap_bp = sum(overlap_bp)), by = gene]

  # Select top N genes by total overlap
  top_genes <- gene_sum[order(-total_overlap_bp)][1:top_n]

  # Print preview
  cat("\n[data.table] Top", top_n, "genes by total overlapped bp:\n")
  print(top_genes)

  # Return list with intermediate data and results
  invisible(list(
    merged = merged,
    gene_sum = gene_sum,
    top_genes = top_genes
  ))
}

######################################################################################################################################################################################

#' Map SNPs to Genes and Count HIGH-Impact Variants
#'
#' This function maps single nucleotide polymorphisms (SNPs) to gene coordinates,
#' filters for HIGH-impact variants, and summarizes the number of such variants per gene
#' and per sample.
#'
#' @param variants_dt A \code{data.table} containing SNP data with columns:
#'   \code{chr}, \code{pos}, \code{impact}, and \code{sample_id}.
#' @param genes_dt A \code{data.table} containing gene coordinates with columns:
#'   \code{chr}, \code{gene}, \code{start}, and \code{end}.
#'
#' @return A list with four elements:
#' \itemize{
#'   \item \code{merged_hi} – a \code{data.table} of HIGH-impact variants mapped to genes.
#'   \item \code{gene_counts} – a \code{data.table} counting HIGH-impact variants per gene.
#'   \item \code{gene_sample_counts} – a \code{data.table} counting HIGH-impact variants per gene per sample.
#'   \item \code{genes_with_hi} – a character vector of genes that have at least one HIGH-impact variant.
#' }
#'
#' @details
#' The function performs the following steps:
#' \enumerate{
#'   \item Converts SNP positions to 1-bp intervals.
#'   \item Ensures gene start/end coordinates are numeric.
#'   \item Merges variants with genes by chromosome, allowing all combinations.
#'   \item Filters to retain only overlapping SNP-gene pairs.
#'   \item Filters only HIGH-impact variants.
#'   \item Computes counts of HIGH-impact variants per gene and per gene per sample.
#'   \item Extracts the list of genes with at least one HIGH-impact variant.
#' }
#'
#' @examples
#' \dontrun{
#' out_dt <- map_snps_to_genes(variants_dt, genes_dt)
#' head(out_dt$gene_counts)
#' head(out_dt$gene_sample_counts)
#' head(out_dt$genes_with_hi, 20)
#' }
#'
#' @export
# Function to map SNPs to genes and count HIGH-impact variants
map_snps_to_genes <- function(variants_dt, genes_dt) {
  # Convert SNP positions into 1-bp intervals
  variants_dt[, `:=`(start = as.numeric(pos), end = as.numeric(pos))]

  # Ensure gene start/end positions are numeric
  genes_dt[, `:=`(start = as.numeric(start), end = as.numeric(end))]

  # Merge by chromosome
  merged <- merge(variants_dt, genes_dt, by = "chr", allow.cartesian = TRUE)

  # Keep only overlapping intervals
  merged <- merged[end.x >= start.y & start.x <= end.y]

  # Filter only HIGH-impact variants
  merged_hi <- merged[impact == "HIGH"]

  # Count HIGH-impact variants per gene
  gene_counts <- merged_hi[, .(HIGH_impact_count = .N), by = gene]

  # Count HIGH-impact variants per gene and per sample
  gene_sample_counts <- merged_hi[, .(HIGH_impact_count = .N), by = .(gene, sample_id)]

  # List of genes with HIGH-impact variants
  genes_with_hi <- unique(merged_hi$gene)

  # Previews
  cat("\n[data.table] HIGH-impact variants per gene (first 6 rows):\n")
  print(head(gene_counts))

  cat("\n[data.table] HIGH-impact variants per gene per sample (first 6 rows):\n")
  print(head(gene_sample_counts))

  cat("\n[data.table] Genes with HIGH-impact variants (first 20):\n")
  print(head(genes_with_hi, 20))

  # Return list with intermediate and final results
  invisible(list(
    merged_hi = merged_hi,
    gene_counts = gene_counts,
    gene_sample_counts = gene_sample_counts,
    genes_with_hi = genes_with_hi
  ))
}

######################################################################################################################################################################################

#' Compute Top Most Variable Genes with Preview
#'
#' This function identifies the top most variable genes based on count variance across all samples,
#' prints a preview of the top genes, and calculates mean counts per cohort and condition for these genes.
#'
#' @param cohortA_dt A \code{data.table} containing metadata for cohort A, including at least
#'   \code{sample_id}, \code{cohort}, and \code{condition}.
#' @param cohortB_dt A \code{data.table} containing metadata for cohort B, including at least
#'   \code{sample_id}, \code{cohort}, and \code{condition}.
#' @param counts_dt A \code{data.table} containing gene expression counts with columns \code{gene},
#'   \code{sample_id}, and \code{count}.
#' @param top_n Integer specifying the number of top most variable genes to select (default 100).
#' @param preview_n Integer specifying the number of top genes to print in the preview (default 10).
#'
#' @return A \code{data.table} with the mean counts per gene for each cohort and condition, restricted
#'   to the top most variable genes.
#'
#' @details
#' The function performs the following steps:
#' \enumerate{
#'   \item Combines cohort A and B metadata.
#'   \item Sorts samples by cohort, condition, and sample_id.
#'   \item Joins the combined metadata with count data.
#'   \item Computes the variance of counts for each gene across all samples.
#'   \item Selects the top N genes with the highest variance.
#'   \item Prints a preview of the top most variable genes.
#'   \item Calculates mean counts per cohort and condition for the selected genes.
#' }
#'
#' @examples
#' \dontrun{
#' out_dt <- compute_top_genes_dt(cohortA, cohortB, counts)
#' head(out_dt)
#' }
#'
#' @export
# Function to compute the top most variable genes with a preview
compute_top_genes_dt <- function(cohortA_dt, cohortB_dt, counts_dt, top_n = 100, preview_n = 10) {
  # Combine cohorts
  combined <- rbindlist(list(cohortA_dt, cohortB_dt), use.names = TRUE, fill = TRUE)

  # Sort by cohort, condition, sample_id
  setorder(combined, cohort, condition, sample_id)

  # Join with counts
  dt <- merge(counts_dt, combined[, .(sample_id, cohort, condition)], by = "sample_id")

  # Calculate variance per gene
  gene_var <- dt[, .(var_count = var(count, na.rm = TRUE)), by = gene]

  # Select top N most variable genes
  top_genes <- gene_var[order(-var_count)][1:top_n, gene]

  # Print preview of top most variable genes
  cat("\n[data.table] Top", preview_n, "most variable genes:\n")
  print(gene_var[gene %in% top_genes][order(-var_count)][1:preview_n])

  # Calculate mean counts per cohort x condition for top genes
  res <- dt[gene %in% top_genes, .(
    mean_count = mean(count, na.rm = TRUE)
  ), by = .(gene, cohort, condition)]

  return(res)
}

######################################################################################################################################################################################
#' Process Cell Type Integration and Summarize Distributions (data.table)
#'
#' This function integrates cell type annotations with clustering results using \code{data.table},
#' calculates counts and percentages of cells per integration cluster and sample type,
#' and generates summary CSV files and a stacked bar plot.
#'
#' @param annot_dt A \code{data.table} containing cell annotation metadata, including a \code{cell} column
#'   and \code{sample_type} (e.g., "N" for Normal, "T" for Tumor).
#' @param ct_dt A \code{data.table} containing cell type integration results with columns \code{cell},
#'   \code{integration_cluster}, and \code{cell_type}.
#'
#' @return A list with three elements:
#' \itemize{
#'   \item \code{merged} – merged table of annotations and cell type integration results.
#'   \item \code{counts} – number of cells per integration cluster and cell type.
#'   \item \code{summary} – normalized summary with percentages of cells per cluster and sample type.
#' }
#'
#' @details
#' Steps performed by the function:
#' \enumerate{
#'   \item Clean cell identifiers by removing unwanted characters and trimming whitespace.
#'   \item Merge annotation data with cell type integration results.
#'   \item Compute raw counts and normalized percentages of each cell type per cluster and sample type.
#'   \item Save CSV files for merged data, counts, and normalized summaries.
#'   \item Generate a stacked bar plot showing the distribution of cell types across integration clusters,
#'         faceted by sample type, and save as PDF.
#' }
#'
#' @examples
#' \dontrun{
#' res_dt <- process_celltype_integration_dt(annot_dt, ct_dt)
#' head(res_dt$counts)
#' head(res_dt$summary)
#' }
#'
#' @export
process_celltype_integration_dt <- function(annot_dt, ct_dt) {
  library(data.table)
  library(ggplot2)

  message("Processing with data.table...")

  # Clean cell identifiers
  annot_dt[, cell := gsub("_X_", "", cell)]
  annot_dt[, cell := trimws(cell)]
  ct_dt[, cell := trimws(cell)]

  # Merge annotation and cell type tables
  merged_dt <- merge(ct_dt, annot_dt, by = "cell", all = FALSE)
  fwrite(merged_dt, "merged_celltype_integration.csv")

  # Counts and summaries per cluster and cell type
  celltype_counts <- merged_dt[, .N, by = .(integration_cluster, cell_type)]
  setnames(celltype_counts, "N", "cell_count")
  fwrite(celltype_counts, "celltype_counts_per_cluster.csv")

  # Summary table with counts and percentages per cluster and sample type
  summary_dt <- merged_dt[, .N, by = .(integration_cluster, cell_type, sample_type)]
  setnames(summary_dt, "N", "cell_count")
  summary_dt[, cluster_total := sum(cell_count), by = .(integration_cluster, sample_type)]
  summary_dt[, pct := (cell_count / cluster_total) * 100]
  fwrite(summary_dt, "celltype_cluster_tissue_summary_normalized.csv")

  # Prepare data for plotting
  summary_dt <- summary_dt[!is.na(sample_type) & !is.na(cell_type)]
  summary_dt[, sample_type := factor(sample_type, levels = c("N", "T"), labels = c("Normal", "Tumor"))]
  summary_dt[, integration_cluster := factor(integration_cluster)]

  # Plot stacked bar chart of cell type distribution per cluster
  plot <- ggplot(summary_dt, aes(x = integration_cluster, y = pct, fill = cell_type)) +
    geom_bar(stat = "identity", position = "stack") +
    facet_wrap(~ sample_type, ncol = 1) +
    labs(title = "Distribution of Cell Types per Integration Cluster",
         x = "Integration Cluster", y = "Percentage of Cells", fill = "Cell Type") +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1))
  ggsave("celltype_distribution_per_cluster.pdf", plot, width = 10, height = 6)

  return(list(merged = merged_dt, counts = celltype_counts, summary = summary_dt))
}

######################################################################################################################################################################################
#' Process Cell Type Integration and Summarize Distributions (data.frame)
#'
#' This function integrates cell type annotations with clustering results using \code{data.frame} and \code{dplyr},
#' calculates counts and percentages of cells per integration cluster and sample type,
#' and generates summary CSV files and a stacked bar plot.
#'
#' @param annot_df A \code{data.frame} containing cell annotation metadata, including a \code{cell} column
#'   and \code{sample_type} (e.g., "N" for Normal, "T" for Tumor).
#' @param ct_df A \code{data.frame} containing cell type integration results with columns \code{cell},
#'   \code{integration_cluster}, and \code{cell_type}.
#'
#' @return A list with three elements:
#' \itemize{
#'   \item \code{merged} – merged table of annotations and cell type integration results.
#'   \item \code{counts} – number of cells per integration cluster and cell type.
#'   \item \code{summary} – normalized summary with percentages of cells per cluster and sample type.
#' }
#'
#' @details
#' Steps performed by the function:
#' \enumerate{
#'   \item Clean cell identifiers by removing unwanted characters and trimming whitespace.
#'   \item Merge annotation data with cell type integration results.
#'   \item Compute raw counts and normalized percentages of each cell type per cluster and sample type.
#'   \item Save CSV files for merged data, counts, and normalized summaries.
#'   \item Generate a stacked bar plot showing the distribution of cell types across integration clusters,
#'         faceted by sample type, and save as PDF.
#' }
#'
#' @examples
#' \dontrun{
#' res_df <- process_celltype_integration_df(annot_df, ct_df)
#' head(res_df$counts)
#' head(res_df$summary)
#' }
#'
#' @export
process_celltype_integration_df <- function(annot_df, ct_df) {
  library(dplyr)
  library(ggplot2)

  message("Processing with data.frame...")

  # Clean cell identifiers
  annot_df$cell <- trimws(gsub("_X_", "", annot_df$cell))
  ct_df$cell <- trimws(ct_df$cell)

  # Merge annotation and cell type tables
  merged_df <- merge(ct_df, annot_df, by = "cell")
  write.csv(merged_df, "merged_celltype_integration_df.csv", row.names = FALSE)

  # Counts and summaries per cluster and cell type
  celltype_counts <- merged_df %>%
    group_by(integration_cluster, cell_type) %>%
    summarise(cell_count = n(), .groups = "drop")
  write.csv(celltype_counts, "celltype_counts_per_cluster_df.csv", row.names = FALSE)

  # Summary table with counts and percentages per cluster and sample type
  summary_df <- merged_df %>%
    group_by(integration_cluster, cell_type, sample_type) %>%
    summarise(cell_count = n(), .groups = "drop") %>%
    group_by(integration_cluster, sample_type) %>%
    mutate(cluster_total = sum(cell_count),
           pct = (cell_count / cluster_total) * 100) %>%
    ungroup()
  write.csv(summary_df, "celltype_cluster_tissue_summary_normalized_df.csv", row.names = FALSE)

  # Prepare data for plotting
  summary_df <- summary_df[!is.na(summary_df$sample_type) & !is.na(summary_df$cell_type), ]
  summary_df$sample_type <- factor(summary_df$sample_type, levels = c("N", "T"), labels = c("Normal", "Tumor"))
  summary_df$integration_cluster <- factor(summary_df$integration_cluster)

  # Plot stacked bar chart of cell type distribution per cluster
  plot <- ggplot(summary_df, aes(x = integration_cluster, y = pct, fill = cell_type)) +
    geom_bar(stat = "identity", position = "stack") +
    facet_wrap(~ sample_type, ncol = 1) +
    labs(title = "Distribution of Cell Types per Integration Cluster",
         x = "Integration Cluster", y = "Percentage of Cells", fill = "Cell Type") +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1))
  ggsave("celltype_distribution_per_cluster_df.pdf", plot, width = 10, height = 6)

  return(list(merged = merged_df, counts = celltype_counts, summary = summary_df))
}

######################################################################################################################################################################################
#' Compare Performance of Cell Type Integration: data.table vs data.frame
#'
#' This function benchmarks the execution time of the cell type integration and summarization workflow
#' implemented using \code{data.table} versus \code{data.frame}/\code{dplyr}.
#'
#' @param annot_dt A \code{data.table} containing cell annotation metadata, including a \code{cell} column
#'   and \code{sample_type} (e.g., "N" for Normal, "T" for Tumor").
#' @param ct_dt A \code{data.table} containing cell type integration results with columns \code{cell},
#'   \code{integration_cluster}, and \code{cell_type}.
#'
#' @return A list with two elements:
#' \itemize{
#'   \item \code{times} – a \code{microbenchmark} object with execution times for both methods.
#'   \item \code{summary} – a \code{data.frame} summarizing median execution times (in seconds) for
#'         \code{data.table} and \code{data.frame} implementations.
#' }
#'
#' @details
#' The function performs the following steps:
#' \enumerate{
#'   \item Runs \code{process_celltype_integration_dt} (data.table version) on the input datasets.
#'   \item Runs \code{process_celltype_integration_df} (data.frame/dplyr version) on the same datasets.
#'   \item Measures execution times using \code{microbenchmark}.
#'   \item Computes median execution times for each method and returns a summary table.
#' }
#'
#' @examples
#' \dontrun{
#' perf <- compare_performance_integration(annot_dt, ct_dt)
#' print(perf$summary)
#' }
#'
#' @export
compare_performance_integration <- function(annot_dt, ct_dt) {
  library(microbenchmark)

  # Measure execution times
  times <- microbenchmark(
    data_table = process_celltype_integration_dt(annot_dt, ct_dt),
    data_frame = process_celltype_integration_df(as.data.frame(annot_dt), as.data.frame(ct_dt)),
    times = 3  # you can increase the number of iterations for more stable results
  )

  # Summary table of median execution times in seconds
  summary_table <- data.frame(
    method = c("data.table", "data.frame"),
    median_time_sec = c(
      median(times$time[times$expr == "data_table"]) / 1e9,
      median(times$time[times$expr == "data_frame"]) / 1e9
    )
  )

  return(list(times = times, summary = summary_table))
}
